<?php
header('Content-Type: application/json');

// Conexión a la base de datos
$conexion = new mysqli("localhost", "root", "", "amyyemporio");
if ($conexion->connect_error) {
    echo json_encode(["success" => false, "error" => "Error de conexión"]);
    exit;
}

// Leer los datos del cuerpo JSON
$data = json_decode(file_get_contents("php://input"), true);

// Validar que haya datos y productos
if (
    !$data ||
    !isset($data['productos']) || count($data['productos']) === 0 ||
    empty($data['nombre']) ||
    empty($data['apellido']) ||
    empty($data['telefono']) ||
    empty($data['localidad']) ||
    empty($data['puntoEntrega']) ||
    !isset($data['total'])
) {
    echo json_encode(["success" => false, "error" => "Datos incompletos"]);
    exit;
}

// Validar teléfono (solo números y 10 dígitos)
if (!preg_match('/^\d{10}$/', $data['telefono'])) {
    echo json_encode(["success" => false, "error" => "Teléfono inválido"]);
    exit;
}

// Datos del cliente y venta
$nombre = $data['nombre'];
$apellido = $data['apellido'];
$telefono = $data['telefono'];
$localidad = $data['localidad'];
$puntoEntrega = $data['puntoEntrega'];
$total = $data['total'];

// Paso 1: Insertar cliente
$stmt = $conexion->prepare("INSERT INTO cliente (nombre, apellido) VALUES (?, ?)");
$stmt->bind_param("ss", $nombre, $apellido);
$stmt->execute();
$id_cliente = $stmt->insert_id;
$stmt->close();

// Paso 2: Insertar punto de entrega
$stmt = $conexion->prepare("INSERT INTO entregas (lugar) VALUES (?)");
$stmt->bind_param("s", $puntoEntrega);
$stmt->execute();
$id_entrega = $stmt->insert_id;
$stmt->close();

// Paso 3: Insertar venta
$stmt = $conexion->prepare("INSERT INTO ventas (id_cliente, id_entrega, total) VALUES (?, ?, ?)");
$stmt->bind_param("iid", $id_cliente, $id_entrega, $total);
$stmt->execute();
$id_venta = $stmt->insert_id;
$stmt->close();

// Paso 4: Insertar productos y detalles
foreach ($data['productos'] as $producto) {
    $nombreProd = $producto['name'];
    $cantidad = $producto['quantity'];
    $precio_unitario = $producto['price'];
    $color = isset($producto['color']) ? $producto['color'] : '';

    // Buscar si el producto ya existe
    $stmt = $conexion->prepare("SELECT id_producto FROM productos WHERE nombre = ? LIMIT 1");
    $stmt->bind_param("s", $nombreProd);
    $stmt->execute();
    $stmt->bind_result($id_producto);
    $stmt->fetch();
    $stmt->close();

    // Si no existe, lo insertamos
    if (!$id_producto) {
        $stmt = $conexion->prepare("INSERT INTO productos (nombre, color, precio) VALUES (?, ?, ?)");
        $stmt->bind_param("ssd", $nombreProd, $color, $precio_unitario);
        $stmt->execute();
        $id_producto = $stmt->insert_id;
        $stmt->close();
    }

    // Insertar en detalle_venta
    $stmt = $conexion->prepare("INSERT INTO detalle_venta (id_venta, id_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiid", $id_venta, $id_producto, $cantidad, $precio_unitario);
    $stmt->execute();
    $stmt->close();
}

// Todo correcto
echo json_encode(["success" => true]);
?>
